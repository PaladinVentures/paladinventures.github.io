<?php /*
* @package Js Menu
* @copyright (C) 2014 by JoomlaStars - All rights reserved!
* @license GNU/GPL, see LICENSE.php
*/
defined('_JEXEC') or die('Restricted access');

$jsnavigationmenu->render($params);

?>